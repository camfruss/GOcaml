(* bs757, cfr59; cvm36 *)
let hours_worked = [11; 35; 14]
